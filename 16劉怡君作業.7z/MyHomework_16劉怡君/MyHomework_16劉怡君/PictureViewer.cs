﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyHomework_16劉怡君
{
    public partial class PictureViewer : Form
    {
        public PictureViewer()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            _1 f1 = new _1();
            f1.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            _2 f2 = new _2();
            f2.Show();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            _3 f3 = new _3();
            f3.Show();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            _4 f4 = new _4();
            f4.Show();
        }
    }
}
