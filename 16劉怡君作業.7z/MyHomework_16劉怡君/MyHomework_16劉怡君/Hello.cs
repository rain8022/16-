﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyHomework_16劉怡君
{
    public partial class Hello : Form
    {
        public Hello()
        {
            InitializeComponent();
        }

        private void Hello_Load(object sender, EventArgs e)
        {

        }

        private void btnHello_Click(object sender, EventArgs e)
        {
            string NameChinese = txtNameChinese.Text;
            string strNameEnglish = txtNameEnglish.Text;
            string strGender = txtGender.Text;
            string strConstellation = txtConstellation.Text;

            MessageBox.Show("Hello,我是" + NameChinese + "\n" + "英文名字是" + strNameEnglish + "\n" + "性別是," + strGender + "\n" + "星座是," + strConstellation + "\n" + "很高興認識你。");


        }

        private void btnHi_Click(object sender, EventArgs e)
        {
            string NameChinese = txtNameChinese.Text;
            string strNameEnglish = txtNameEnglish.Text;
            string strGender = txtGender.Text;
            string strConstellation = txtConstellation.Text;
            MessageBox.Show("Hi,我是" + NameChinese + "\n" + "英文名字是" + strNameEnglish + "\n" + "性別是," + strGender + "\n" + "星座是," + strConstellation + "\n" + "很高興認識你。");
        }

    }
}
