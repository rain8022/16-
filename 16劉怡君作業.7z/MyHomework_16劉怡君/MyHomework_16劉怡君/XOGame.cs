﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyHomework_16劉怡君
{
    public partial class XOGame : Form
    {
        bool isX = true;
       
      
        public XOGame()
        {
            InitializeComponent();
        }

        private void testWin()
        {
            if (btn1.Text == "X" && btn2.Text == "X" && btn3.Text == "X") MessageBox.Show("X WIN!");
            if (btn4.Text == "X" && btn5.Text == "X" && btn6.Text == "X") MessageBox.Show("X WIN!");
            if (btn7.Text == "X" && btn8.Text == "X" && btn9.Text == "X") MessageBox.Show("X WIN!");
            if (btn1.Text == "X" && btn4.Text == "X" && btn7.Text == "X") MessageBox.Show("X WIN!");
            if (btn2.Text == "X" && btn5.Text == "X" && btn8.Text == "X") MessageBox.Show("X WIN!");
            if (btn3.Text == "X" && btn6.Text == "X" && btn9.Text == "X") MessageBox.Show("X WIN!");
            if (btn1.Text == "X" && btn5.Text == "X" && btn9.Text == "X") MessageBox.Show("X WIN!");
            if (btn3.Text == "X" && btn5.Text == "X" && btn7.Text == "X") MessageBox.Show("X WIN!");
            if (btn1.Text == "0" && btn2.Text == "0" && btn3.Text == "0") MessageBox.Show("O WIN!");
            if (btn4.Text == "0" && btn5.Text == "0" && btn6.Text == "0") MessageBox.Show("O WIN!");
            if (btn7.Text == "0" && btn8.Text == "0" && btn9.Text == "0") MessageBox.Show("O WIN!");
            if (btn1.Text == "0" && btn4.Text == "0" && btn7.Text == "0") MessageBox.Show("O WIN!");
            if (btn2.Text == "0" && btn5.Text == "0" && btn8.Text == "0") MessageBox.Show("O WIN!");
            if (btn3.Text == "0" && btn6.Text == "0" && btn9.Text == "0") MessageBox.Show("O WIN!");
            if (btn1.Text == "0" && btn5.Text == "0" && btn9.Text == "0") MessageBox.Show("O WIN!");
            if (btn3.Text == "0" && btn5.Text == "0" && btn7.Text == "0") MessageBox.Show("O WIN!");
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (isX == true)
            {
                btn1.Text = "X";
                isX = false;
            }
            else
            {
                btn1.Text = "0";
                isX = true;
            }
            testWin();
            
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            if (isX == true)
            {
                btn2.Text = "X";
                isX = false;
            }
            else
            {
                btn2.Text = "0";
                isX = true;
            }
            testWin();
            
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            if (isX == true)
            {
                btn3.Text = "X";
                isX = false;
            }
            else
            {
                btn3.Text = "0";
                isX = true;
            }
            testWin();
            
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            if (isX == true)
            {
                btn4.Text = "X";
                isX = false;
            }
            else
            {
                btn4.Text = "0";
                isX = true;
            }
            testWin();
            
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            if (isX == true)
            {
                btn5.Text = "X";
                isX = false;
            }
            else
            {
                btn5.Text = "0";
                isX = true;
            }
            testWin();
            
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            if (isX == true)
            {
                btn6.Text = "X";
                isX = false;
            }
            else
            {
                btn6.Text = "0";
                isX = true;
            }
            testWin();
            
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            if (isX == true)
            {
                btn7.Text = "X";
                isX = false;
            }
            else
            {
                btn7.Text = "0";
                isX = true;
            }
            testWin();
           
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            if (isX == true)
            {
                btn8.Text = "X";
                isX = false;
            }
            else
            {
                btn8.Text = "0";
                isX = true;
            }
            testWin();
            
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            if (isX == true)
            {
                btn9.Text = "X";
                isX = false;
            }
            else
            {
                btn9.Text = "0";
                isX = true;
            }
            testWin();
            
        }

        private void button10_Click(object sender, EventArgs e)
        {
            btn1.Text = "";
            btn2.Text = "";
            btn3.Text = "";
            btn4.Text = "";
            btn5.Text = "";
            btn6.Text = "";
            btn7.Text = "";
            btn8.Text = "";
            btn9.Text = "";
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
