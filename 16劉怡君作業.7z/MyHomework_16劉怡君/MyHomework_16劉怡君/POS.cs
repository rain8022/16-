﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyHomework_16劉怡君
{
    public partial class POS : Form
    {
       
        public POS()
        {
            InitializeComponent();
        }

        public class Product
        {
            public string Name;
            public int Count;
            public int Price;
        }

        Product guzzle1 = new Product()
        {
            Name = "花花公子Boulevadier",
            Count = 0,
            Price = 350
        };

        Product guzzle2 = new Product()
        {
            Name = "皮斯可酸酒Pisco sour",
            Count = 0,
            Price = 300
        };

        Product guzzle3 = new Product()
        {
            Name = "綠色蚱蜢grass hopper",
            Count = 0,
            Price = 280
        };

        Product guzzle4 = new Product()
        {
            Name = "美國佬Americano",
            Count = 0,
            Price = 280
        };

        int Tatal_Price = 0;

        void Method(Product pro)
        {

            Tatal_Price += pro.Price;
            txtTotalPrice.Text = "NT$ " + Tatal_Price.ToString();
            if (txtList.Text.Contains("尚未點餐"))
            {
                txtList.Text = "";
            }
            if (!txtList.Text.Contains(pro.Name + " x" + pro.Count.ToString() + ",共NT$ " + (pro.Price * pro.Count).ToString() + "元"))
            {
                txtList.Text += pro.Name + " x" + pro.Count.ToString() + ",共NT$ " + (pro.Price * pro.Count).ToString() + "元" + "\r\n";
            }
            if (txtList.Text.Contains(pro.Name + " x" + pro.Count.ToString() + ",共NT$ " + (pro.Price * pro.Count).ToString() + "元"))
            {
                pro.Count += 1;
                txtList.Text = txtList.Text.Replace(pro.Name + " x" + (pro.Count - 1).ToString() + ",共NT$ " + (pro.Price * (pro.Count - 1)).ToString() + "元", pro.Name + " x" + pro.Count.ToString() + ",共NT$ " + (pro.Price * pro.Count).ToString() + "元");
            }

        }

        private void btnguzzle1_Click(object sender, EventArgs e)
        {
            Method(guzzle1);
        }

        private void btnguzzle2_Click(object sender, EventArgs e)
        {
            Method(guzzle2);
        }

        private void btnguzzle3_Click(object sender, EventArgs e)
        {
            Method(guzzle3);
        }

        private void btnguzzle4_Click(object sender, EventArgs e)
        {
            Method(guzzle4);
        }

       
        private void btncash_Click(object sender, EventArgs e)
        {
            MessageBox.Show("總金額:" + Tatal_Price.ToString()+"元");
        }

        private void btncard_Click(object sender, EventArgs e)
        {
            MessageBox.Show("總金額:"+Tatal_Price+"元"+"\n" +"折扣後金額:"+ (Tatal_Price*0.9).ToString() + "元");
        }

        private void btnListclear_Click(object sender, EventArgs e)
        {
            Tatal_Price = 0;
            guzzle1.Count = 0;
            guzzle2.Count = 0;
            guzzle3.Count = 0;
            guzzle4.Count = 0;
            txtList.Text = "尚未點餐";
            txtTotalPrice.Text = "NT$ 0";
        }
    }
}
