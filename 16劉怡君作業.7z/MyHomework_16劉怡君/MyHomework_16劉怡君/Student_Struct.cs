﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyHomework_16劉怡君
{
    public partial class Student_Struct : Form
    {
        public Student_Struct()
        {
            InitializeComponent();
        }

        string str; 

        private void btnStore_Click(object sender, EventArgs e)
        {
            str = "姓名" + txtName.Text + "\r\n" + "國文:" + txtChinese.Text + "分" + "\r\n" + "英文:" + txtEnglish.Text + "分" + "\r\n" + "數學:" + txtMath.Text + "分";
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            txtscore.Text = str;
        }

        private void btnMaxMin_Click(object sender, EventArgs e)
        {
            int chinese = Convert.ToInt32(txtChinese.Text);
            int english = Convert.ToInt32(txtEnglish.Text);
            int math = Convert.ToInt32(txtMath.Text);
            int[] array = { chinese, english, math };
            string suject;
            string suject2;

            void Method() { textBox2.Text= "最高科目成績為:" + suject + array.Max() + "分" + "\r\n最低科目成績為:" + suject2 + array.Min() + "分";}

            if (array.Max()==chinese)
            {
                suject = "國文";

                if(array.Min()==english)
                {
                    suject2 = "英文";
                    Method();
                }
                if(array.Min()==math)
                {
                    suject2 = "數學";
                    Method();
                }
            }
            if(array.Max()==english)
            {
                suject = "英文";
                if(array.Min()==chinese)
                {
                    suject2 = "國文";
                    Method();
                }
                if(array.Min()==math)
                {
                    suject2 = "數學";
                    Method();
                }
            }
            if (array.Max()==math)
            {
                suject = "數學";
                if(array.Min()==chinese)
                {
                    suject2 = "國文";
                    Method();
                }
                if(array.Min()==english)
                {
                    suject2 = "英文";
                    Method();
                }
            }

        }
    }
}
