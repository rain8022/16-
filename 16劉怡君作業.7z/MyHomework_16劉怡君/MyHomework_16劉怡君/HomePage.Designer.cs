﻿
namespace MyHomework_16劉怡君
{
    partial class HomePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button button1;
            System.Windows.Forms.Button button2;
            System.Windows.Forms.Button button3;
            System.Windows.Forms.Button button4;
            System.Windows.Forms.Button button5;
            System.Windows.Forms.Button button6;
            System.Windows.Forms.Button button7;
            System.Windows.Forms.Button button8;
            this.label1 = new System.Windows.Forms.Label();
            button1 = new System.Windows.Forms.Button();
            button2 = new System.Windows.Forms.Button();
            button3 = new System.Windows.Forms.Button();
            button4 = new System.Windows.Forms.Button();
            button5 = new System.Windows.Forms.Button();
            button6 = new System.Windows.Forms.Button();
            button7 = new System.Windows.Forms.Button();
            button8 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            button1.AutoSize = true;
            button1.BackColor = System.Drawing.SystemColors.ControlLight;
            button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            button1.CausesValidation = false;
            button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button1.Font = new System.Drawing.Font("標楷體", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            button1.ForeColor = System.Drawing.SystemColors.ControlText;
            button1.Location = new System.Drawing.Point(145, 113);
            button1.Name = "button1";
            button1.Size = new System.Drawing.Size(173, 53);
            button1.TabIndex = 0;
            button1.Text = "Hello";
            button1.UseVisualStyleBackColor = false;
            button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            button2.AutoSize = true;
            button2.BackColor = System.Drawing.SystemColors.ControlLight;
            button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            button2.CausesValidation = false;
            button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button2.Font = new System.Drawing.Font("標楷體", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            button2.ForeColor = System.Drawing.SystemColors.ControlText;
            button2.Location = new System.Drawing.Point(145, 191);
            button2.Name = "button2";
            button2.Size = new System.Drawing.Size(173, 53);
            button2.TabIndex = 1;
            button2.Text = "Loan";
            button2.UseVisualStyleBackColor = false;
            button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            button3.AutoSize = true;
            button3.BackColor = System.Drawing.SystemColors.ControlLight;
            button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            button3.CausesValidation = false;
            button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button3.Font = new System.Drawing.Font("標楷體", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            button3.ForeColor = System.Drawing.SystemColors.ControlText;
            button3.Location = new System.Drawing.Point(145, 264);
            button3.Name = "button3";
            button3.Size = new System.Drawing.Size(173, 53);
            button3.TabIndex = 2;
            button3.Text = "POS";
            button3.UseVisualStyleBackColor = false;
            button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            button4.AutoSize = true;
            button4.BackColor = System.Drawing.SystemColors.ControlLight;
            button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            button4.CausesValidation = false;
            button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button4.Font = new System.Drawing.Font("標楷體", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            button4.ForeColor = System.Drawing.SystemColors.ControlText;
            button4.Location = new System.Drawing.Point(145, 351);
            button4.Name = "button4";
            button4.Size = new System.Drawing.Size(173, 53);
            button4.TabIndex = 4;
            button4.Text = "XOGame";
            button4.UseVisualStyleBackColor = false;
            button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            button5.AutoSize = true;
            button5.BackColor = System.Drawing.SystemColors.ControlLight;
            button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            button5.CausesValidation = false;
            button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button5.Font = new System.Drawing.Font("標楷體", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            button5.ForeColor = System.Drawing.SystemColors.ControlText;
            button5.Location = new System.Drawing.Point(145, 434);
            button5.Name = "button5";
            button5.Size = new System.Drawing.Size(173, 53);
            button5.TabIndex = 5;
            button5.Text = "MyClac";
            button5.UseVisualStyleBackColor = false;
            button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            button6.AutoSize = true;
            button6.BackColor = System.Drawing.SystemColors.ControlLight;
            button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            button6.CausesValidation = false;
            button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button6.Font = new System.Drawing.Font("標楷體", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            button6.ForeColor = System.Drawing.SystemColors.ControlText;
            button6.Location = new System.Drawing.Point(145, 511);
            button6.Name = "button6";
            button6.Size = new System.Drawing.Size(231, 53);
            button6.TabIndex = 6;
            button6.Text = "Screen Saver";
            button6.UseVisualStyleBackColor = false;
            button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            button7.AutoSize = true;
            button7.BackColor = System.Drawing.SystemColors.ControlLight;
            button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            button7.CausesValidation = false;
            button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button7.Font = new System.Drawing.Font("標楷體", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            button7.ForeColor = System.Drawing.SystemColors.ControlText;
            button7.Location = new System.Drawing.Point(145, 586);
            button7.Name = "button7";
            button7.Size = new System.Drawing.Size(248, 53);
            button7.TabIndex = 7;
            button7.Text = "PictureViewer";
            button7.UseVisualStyleBackColor = false;
            button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            button8.AutoSize = true;
            button8.BackColor = System.Drawing.SystemColors.ControlLight;
            button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            button8.CausesValidation = false;
            button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button8.Font = new System.Drawing.Font("標楷體", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            button8.ForeColor = System.Drawing.SystemColors.ControlText;
            button8.Location = new System.Drawing.Point(145, 661);
            button8.Name = "button8";
            button8.Size = new System.Drawing.Size(282, 53);
            button8.TabIndex = 8;
            button8.Text = " Student Struct";
            button8.UseVisualStyleBackColor = false;
            button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(429, 438);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 40);
            this.label1.TabIndex = 3;
            // 
            // HomePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::MyHomework_16劉怡君.Properties.Resources.H_1;
            this.ClientSize = new System.Drawing.Size(1003, 1050);
            this.Controls.Add(button8);
            this.Controls.Add(button7);
            this.Controls.Add(button6);
            this.Controls.Add(button5);
            this.Controls.Add(button4);
            this.Controls.Add(this.label1);
            this.Controls.Add(button3);
            this.Controls.Add(button2);
            this.Controls.Add(button1);
            this.Name = "HomePage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "HomePage";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
    }
}