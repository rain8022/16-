﻿
namespace MyHomework_16劉怡君
{
    partial class Hello
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labNameChinese = new System.Windows.Forms.Label();
            this.txtNameChinese = new System.Windows.Forms.TextBox();
            this.txtNameEnglish = new System.Windows.Forms.TextBox();
            this.labNameEnglish = new System.Windows.Forms.Label();
            this.txtGender = new System.Windows.Forms.TextBox();
            this.labGender = new System.Windows.Forms.Label();
            this.txtConstellation = new System.Windows.Forms.TextBox();
            this.labConstellation = new System.Windows.Forms.Label();
            this.btnHello = new System.Windows.Forms.Button();
            this.btnHi = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labNameChinese
            // 
            this.labNameChinese.AutoSize = true;
            this.labNameChinese.Font = new System.Drawing.Font("新細明體", 14F);
            this.labNameChinese.Location = new System.Drawing.Point(60, 157);
            this.labNameChinese.Name = "labNameChinese";
            this.labNameChinese.Size = new System.Drawing.Size(75, 28);
            this.labNameChinese.TabIndex = 0;
            this.labNameChinese.Text = "姓名:";
            // 
            // txtNameChinese
            // 
            this.txtNameChinese.Location = new System.Drawing.Point(255, 156);
            this.txtNameChinese.Name = "txtNameChinese";
            this.txtNameChinese.Size = new System.Drawing.Size(154, 29);
            this.txtNameChinese.TabIndex = 1;
            // 
            // txtNameEnglish
            // 
            this.txtNameEnglish.Location = new System.Drawing.Point(255, 208);
            this.txtNameEnglish.Name = "txtNameEnglish";
            this.txtNameEnglish.Size = new System.Drawing.Size(154, 29);
            this.txtNameEnglish.TabIndex = 3;
            // 
            // labNameEnglish
            // 
            this.labNameEnglish.AutoSize = true;
            this.labNameEnglish.Font = new System.Drawing.Font("新細明體", 14F);
            this.labNameEnglish.Location = new System.Drawing.Point(60, 203);
            this.labNameEnglish.Name = "labNameEnglish";
            this.labNameEnglish.Size = new System.Drawing.Size(168, 28);
            this.labNameEnglish.TabIndex = 2;
            this.labNameEnglish.Text = "English Name:";
            // 
            // txtGender
            // 
            this.txtGender.Location = new System.Drawing.Point(255, 250);
            this.txtGender.Name = "txtGender";
            this.txtGender.Size = new System.Drawing.Size(154, 29);
            this.txtGender.TabIndex = 5;
            // 
            // labGender
            // 
            this.labGender.AutoSize = true;
            this.labGender.Font = new System.Drawing.Font("新細明體", 14F);
            this.labGender.Location = new System.Drawing.Point(60, 251);
            this.labGender.Name = "labGender";
            this.labGender.Size = new System.Drawing.Size(75, 28);
            this.labGender.TabIndex = 4;
            this.labGender.Text = "性別:";
            // 
            // txtConstellation
            // 
            this.txtConstellation.Location = new System.Drawing.Point(255, 295);
            this.txtConstellation.Name = "txtConstellation";
            this.txtConstellation.Size = new System.Drawing.Size(154, 29);
            this.txtConstellation.TabIndex = 7;
            // 
            // labConstellation
            // 
            this.labConstellation.AutoSize = true;
            this.labConstellation.Font = new System.Drawing.Font("新細明體", 14F);
            this.labConstellation.Location = new System.Drawing.Point(60, 295);
            this.labConstellation.Name = "labConstellation";
            this.labConstellation.Size = new System.Drawing.Size(75, 28);
            this.labConstellation.TabIndex = 6;
            this.labConstellation.Text = "星座:";
            // 
            // btnHello
            // 
            this.btnHello.BackColor = System.Drawing.Color.Moccasin;
            this.btnHello.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnHello.Location = new System.Drawing.Point(526, 156);
            this.btnHello.Name = "btnHello";
            this.btnHello.Size = new System.Drawing.Size(234, 59);
            this.btnHello.TabIndex = 8;
            this.btnHello.Text = "Say HELLO!";
            this.btnHello.UseVisualStyleBackColor = false;
            this.btnHello.Click += new System.EventHandler(this.btnHello_Click);
            // 
            // btnHi
            // 
            this.btnHi.BackColor = System.Drawing.Color.Moccasin;
            this.btnHi.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnHi.Location = new System.Drawing.Point(526, 250);
            this.btnHi.Name = "btnHi";
            this.btnHi.Size = new System.Drawing.Size(234, 59);
            this.btnHi.TabIndex = 9;
            this.btnHi.Text = "Say HI!";
            this.btnHi.UseVisualStyleBackColor = false;
            this.btnHi.Click += new System.EventHandler(this.btnHi_Click);
            // 
            // Hello
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::MyHomework_16劉怡君.Properties.Resources.cat1;
            this.ClientSize = new System.Drawing.Size(800, 340);
            this.Controls.Add(this.btnHi);
            this.Controls.Add(this.btnHello);
            this.Controls.Add(this.txtConstellation);
            this.Controls.Add(this.labConstellation);
            this.Controls.Add(this.txtGender);
            this.Controls.Add(this.labGender);
            this.Controls.Add(this.txtNameEnglish);
            this.Controls.Add(this.labNameEnglish);
            this.Controls.Add(this.txtNameChinese);
            this.Controls.Add(this.labNameChinese);
            this.Name = "Hello";
            this.Text = "Hello";
            this.Load += new System.EventHandler(this.Hello_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labNameChinese;
        private System.Windows.Forms.TextBox txtNameChinese;
        private System.Windows.Forms.TextBox txtNameEnglish;
        private System.Windows.Forms.Label labNameEnglish;
        private System.Windows.Forms.TextBox txtGender;
        private System.Windows.Forms.Label labGender;
        private System.Windows.Forms.TextBox txtConstellation;
        private System.Windows.Forms.Label labConstellation;
        private System.Windows.Forms.Button btnHello;
        private System.Windows.Forms.Button btnHi;
    }
}