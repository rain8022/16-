﻿
namespace MyHomework_16劉怡君
{
    partial class LoanReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.labmoney = new System.Windows.Forms.Label();
            this.labyear = new System.Windows.Forms.Label();
            this.labrate = new System.Windows.Forms.Label();
            this.labmo = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.labpay = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 14F);
            this.label1.Location = new System.Drawing.Point(126, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 28);
            this.label1.TabIndex = 0;
            this.label1.Text = "貸款金額:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("新細明體", 14F);
            this.label2.Location = new System.Drawing.Point(126, 108);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 28);
            this.label2.TabIndex = 1;
            this.label2.Text = "期限(年):";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("新細明體", 14F);
            this.label3.Location = new System.Drawing.Point(126, 163);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 28);
            this.label3.TabIndex = 2;
            this.label3.Text = "利率(%)";
            // 
            // labmoney
            // 
            this.labmoney.AutoSize = true;
            this.labmoney.Font = new System.Drawing.Font("新細明體", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labmoney.Location = new System.Drawing.Point(279, 59);
            this.labmoney.Name = "labmoney";
            this.labmoney.Size = new System.Drawing.Size(115, 32);
            this.labmoney.TabIndex = 6;
            this.labmoney.Text = "labshow";
            // 
            // labyear
            // 
            this.labyear.AutoSize = true;
            this.labyear.Font = new System.Drawing.Font("新細明體", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labyear.Location = new System.Drawing.Point(279, 104);
            this.labyear.Name = "labyear";
            this.labyear.Size = new System.Drawing.Size(115, 32);
            this.labyear.TabIndex = 7;
            this.labyear.Text = "labshow";
            // 
            // labrate
            // 
            this.labrate.AutoSize = true;
            this.labrate.Font = new System.Drawing.Font("新細明體", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labrate.Location = new System.Drawing.Point(279, 163);
            this.labrate.Name = "labrate";
            this.labrate.Size = new System.Drawing.Size(115, 32);
            this.labrate.TabIndex = 8;
            this.labrate.Text = "labshow";
            // 
            // labmo
            // 
            this.labmo.AutoSize = true;
            this.labmo.Font = new System.Drawing.Font("新細明體", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labmo.Location = new System.Drawing.Point(279, 215);
            this.labmo.Name = "labmo";
            this.labmo.Size = new System.Drawing.Size(115, 32);
            this.labmo.TabIndex = 9;
            this.labmo.Text = "labshow";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("新細明體", 14F);
            this.label4.Location = new System.Drawing.Point(126, 215);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 28);
            this.label4.TabIndex = 3;
            this.label4.Text = "月付款:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("新細明體", 14F);
            this.label5.Location = new System.Drawing.Point(126, 267);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(103, 28);
            this.label5.TabIndex = 10;
            this.label5.Text = "總付款:";
            // 
            // labpay
            // 
            this.labpay.AutoSize = true;
            this.labpay.Font = new System.Drawing.Font("新細明體", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labpay.Location = new System.Drawing.Point(279, 267);
            this.labpay.Name = "labpay";
            this.labpay.Size = new System.Drawing.Size(115, 32);
            this.labpay.TabIndex = 11;
            this.labpay.Text = "labshow";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("微軟正黑體", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button1.Location = new System.Drawing.Point(542, 297);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(137, 60);
            this.button1.TabIndex = 12;
            this.button1.Text = "email";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // LoanReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.labpay);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.labmo);
            this.Controls.Add(this.labrate);
            this.Controls.Add(this.labyear);
            this.Controls.Add(this.labmoney);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "LoanReport";
            this.Text = "LoanReport";
            this.Load += new System.EventHandler(this.LoanReport_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.Label labmoney;
        public System.Windows.Forms.Label labyear;
        public System.Windows.Forms.Label labrate;
        public System.Windows.Forms.Label labmo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.Label labpay;
        private System.Windows.Forms.Button button1;
    }
}