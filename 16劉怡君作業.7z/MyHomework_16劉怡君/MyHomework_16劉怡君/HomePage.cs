﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyHomework_16劉怡君
{
    public partial class HomePage : Form
    {
        public HomePage()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Hello hello = new Hello();
            hello.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Loan loan = new Loan();
            loan.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            POS pos = new POS();
            pos.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            XOGame xogame = new XOGame();
            xogame.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MyClac myclac = new MyClac();
            myclac.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Screen_Saver screen_Saver = new Screen_Saver();
            screen_Saver.Show();


        }

        private void button7_Click(object sender, EventArgs e)
        {
            PictureViewer pictureViewer = new PictureViewer();
            pictureViewer.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Student_Struct student_Struct = new Student_Struct();
            student_Struct.Show();
        }
    }
}
