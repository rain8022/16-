﻿
namespace MyHomework_16劉怡君
{
    partial class POS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnguzzle1 = new System.Windows.Forms.Button();
            this.btnguzzle2 = new System.Windows.Forms.Button();
            this.btnguzzle4 = new System.Windows.Forms.Button();
            this.btnguzzle3 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtTotalPrice = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btncard = new System.Windows.Forms.Button();
            this.btncash = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btnListclear = new System.Windows.Forms.Button();
            this.txtList = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnguzzle1);
            this.groupBox1.Controls.Add(this.btnguzzle2);
            this.groupBox1.Controls.Add(this.btnguzzle4);
            this.groupBox1.Controls.Add(this.btnguzzle3);
            this.groupBox1.Font = new System.Drawing.Font("Algerian", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.IndianRed;
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(558, 725);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "菜單Menu";
            // 
            // btnguzzle1
            // 
            this.btnguzzle1.BackgroundImage = global::MyHomework_16劉怡君.Properties.Resources.調酒1;
            this.btnguzzle1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnguzzle1.Location = new System.Drawing.Point(19, 33);
            this.btnguzzle1.Name = "btnguzzle1";
            this.btnguzzle1.Size = new System.Drawing.Size(492, 149);
            this.btnguzzle1.TabIndex = 5;
            this.btnguzzle1.UseVisualStyleBackColor = true;
            this.btnguzzle1.Click += new System.EventHandler(this.btnguzzle1_Click);
            // 
            // btnguzzle2
            // 
            this.btnguzzle2.BackgroundImage = global::MyHomework_16劉怡君.Properties.Resources.調酒2;
            this.btnguzzle2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnguzzle2.Location = new System.Drawing.Point(19, 175);
            this.btnguzzle2.Name = "btnguzzle2";
            this.btnguzzle2.Size = new System.Drawing.Size(492, 149);
            this.btnguzzle2.TabIndex = 4;
            this.btnguzzle2.UseVisualStyleBackColor = true;
            this.btnguzzle2.Click += new System.EventHandler(this.btnguzzle2_Click);
            // 
            // btnguzzle4
            // 
            this.btnguzzle4.BackgroundImage = global::MyHomework_16劉怡君.Properties.Resources.調酒4;
            this.btnguzzle4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnguzzle4.Location = new System.Drawing.Point(19, 486);
            this.btnguzzle4.Name = "btnguzzle4";
            this.btnguzzle4.Size = new System.Drawing.Size(492, 152);
            this.btnguzzle4.TabIndex = 3;
            this.btnguzzle4.UseVisualStyleBackColor = true;
            this.btnguzzle4.Click += new System.EventHandler(this.btnguzzle4_Click);
            // 
            // btnguzzle3
            // 
            this.btnguzzle3.BackgroundImage = global::MyHomework_16劉怡君.Properties.Resources.調酒3;
            this.btnguzzle3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnguzzle3.Location = new System.Drawing.Point(19, 330);
            this.btnguzzle3.Name = "btnguzzle3";
            this.btnguzzle3.Size = new System.Drawing.Size(492, 149);
            this.btnguzzle3.TabIndex = 2;
            this.btnguzzle3.UseVisualStyleBackColor = true;
            this.btnguzzle3.Click += new System.EventHandler(this.btnguzzle3_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtTotalPrice);
            this.groupBox2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.Black;
            this.groupBox2.Location = new System.Drawing.Point(587, 68);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(317, 126);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "總金額Total Price";
            // 
            // txtTotalPrice
            // 
            this.txtTotalPrice.BackColor = System.Drawing.Color.Black;
            this.txtTotalPrice.Font = new System.Drawing.Font("Arial", 18F);
            this.txtTotalPrice.ForeColor = System.Drawing.SystemColors.Window;
            this.txtTotalPrice.Location = new System.Drawing.Point(6, 50);
            this.txtTotalPrice.Name = "txtTotalPrice";
            this.txtTotalPrice.Size = new System.Drawing.Size(286, 49);
            this.txtTotalPrice.TabIndex = 0;
            this.txtTotalPrice.Text = "NT$0";
            this.txtTotalPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox3
            // 
            this.groupBox3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.ForeColor = System.Drawing.Color.Black;
            this.groupBox3.Location = new System.Drawing.Point(587, 210);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(317, 223);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "付款方式";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.btncard);
            this.groupBox4.Controls.Add(this.btncash);
            this.groupBox4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.ForeColor = System.Drawing.Color.Black;
            this.groupBox4.Location = new System.Drawing.Point(587, 210);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(317, 185);
            this.groupBox4.TabIndex = 5;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "付款方式";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Location = new System.Drawing.Point(107, 132);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(194, 34);
            this.label1.TabIndex = 2;
            this.label1.Text = "信用卡享九折!";
            // 
            // btncard
            // 
            this.btncard.Font = new System.Drawing.Font("新細明體", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncard.Location = new System.Drawing.Point(162, 52);
            this.btncard.Name = "btncard";
            this.btncard.Size = new System.Drawing.Size(139, 57);
            this.btncard.TabIndex = 1;
            this.btncard.Text = "信用卡";
            this.btncard.UseVisualStyleBackColor = true;
            this.btncard.Click += new System.EventHandler(this.btncard_Click);
            // 
            // btncash
            // 
            this.btncash.Font = new System.Drawing.Font("新細明體", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncash.Location = new System.Drawing.Point(17, 52);
            this.btncash.Name = "btncash";
            this.btncash.Size = new System.Drawing.Size(139, 57);
            this.btncash.TabIndex = 0;
            this.btncash.Text = "現金";
            this.btncash.Click += new System.EventHandler(this.btncash_Click);
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("新細明體", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(196, 407);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(139, 57);
            this.button7.TabIndex = 3;
            this.button7.Text = "清除清單";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(42, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 32);
            this.label2.TabIndex = 0;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btnListclear);
            this.groupBox5.Controls.Add(this.txtList);
            this.groupBox5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.ForeColor = System.Drawing.Color.Black;
            this.groupBox5.Location = new System.Drawing.Point(910, 68);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(373, 521);
            this.groupBox5.TabIndex = 6;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "購物清單";
            // 
            // btnListclear
            // 
            this.btnListclear.Font = new System.Drawing.Font("新細明體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnListclear.Location = new System.Drawing.Point(176, 449);
            this.btnListclear.Margin = new System.Windows.Forms.Padding(4);
            this.btnListclear.Name = "btnListclear";
            this.btnListclear.Size = new System.Drawing.Size(134, 48);
            this.btnListclear.TabIndex = 7;
            this.btnListclear.Text = "清除清單";
            this.btnListclear.UseVisualStyleBackColor = true;
            this.btnListclear.Click += new System.EventHandler(this.btnListclear_Click);
            // 
            // txtList
            // 
            this.txtList.Location = new System.Drawing.Point(14, 50);
            this.txtList.Margin = new System.Windows.Forms.Padding(4);
            this.txtList.Multiline = true;
            this.txtList.Name = "txtList";
            this.txtList.ReadOnly = true;
            this.txtList.Size = new System.Drawing.Size(343, 350);
            this.txtList.TabIndex = 7;
            this.txtList.Text = "尚未點餐";
            this.txtList.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // POS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1333, 1050);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.Name = "POS";
            this.Text = "POS";
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnguzzle4;
        private System.Windows.Forms.Button btnguzzle3;
    
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtTotalPrice;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btncard;
        private System.Windows.Forms.Button btncash;
        private System.Windows.Forms.Button button7;

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnguzzle1;
        private System.Windows.Forms.Button btnguzzle2;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btnListclear;
        private System.Windows.Forms.TextBox txtList;
    }
}