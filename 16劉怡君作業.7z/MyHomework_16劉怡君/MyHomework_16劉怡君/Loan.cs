﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace MyHomework_16劉怡君
{
    public partial class Loan : Form
    {
        public Loan()
        {
            InitializeComponent();
        }

        public string d_t;
        public double abc;
        

        private void button1_Click(object sender, EventArgs e)
        {
            string a_t = textBox1.Text.ToString();
            string b_t = textBox2.Text.ToString();
            double c = double.Parse(textBox3.Text.ToString());
            string f = textBox4.Text.ToString();          
        

            int a = int.Parse(a_t);
            int b = int.Parse(b_t)*12;
            int fa = int.Parse(f);

            //Chuan
            double test = -(Microsoft.VisualBasic.Financial.Pmt((c / 1200), b, a - fa));
            double test_1 = Math.Round(test);
            d_t = test_1.ToString();


            //d_t = Convert.ToString(-(Microsoft.VisualBasic.Financial.Pmt((c / 1200), b, a-fa)));

            MessageBox.Show("月付額:  " + d_t+"元");

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string a_t = textBox1.Text.ToString();
            string b_t = textBox2.Text.ToString();
            double c = double.Parse(textBox3.Text.ToString());
            double d_t, f_t;
            string f = textBox4.Text.ToString();


            int a = int.Parse(a_t);
            int b = int.Parse(b_t)*12;
            int fa = int.Parse(f);

            abc = (-(Microsoft.VisualBasic.Financial.Pmt((c / 1200), b, a)));
            abc = abc * b;


            //double test = -(Microsoft.VisualBasic.Financial.Pmt((c / 1200), b, a - fa));
            //double test_1 = Math.Round(test);
            //d_t = test_1.ToString();

            //d_t = Convert.ToString(-(Microsoft.VisualBasic.Financial.Pmt((c / 1200), b, a-fa)));



            d_t = Math.Round((-(Microsoft.VisualBasic.Financial.Pmt((c / 1200), b, a-fa))));
            f_t = Math.Round(d_t * b);
            
            

            MessageBox.Show("總付款:  " + f_t+"元");
        }

       



        private void button3_Click(object sender, EventArgs e)
        {
            LoanReport loanreport = new LoanReport();
            loanreport.Show();
            loanreport.labmoney.Text = textBox1.Text;
            loanreport.labyear.Text = textBox2.Text;
            loanreport.labrate.Text = textBox3.Text;            
            //loanreport.labmo.Text = d_t;

            string a_t = textBox1.Text.ToString();
            string b_t = textBox2.Text.ToString();
            double c = double.Parse(textBox3.Text.ToString());
            string f = textBox4.Text.ToString();


            int a = int.Parse(a_t);
            int b = int.Parse(b_t) * 12;
            int fa = int.Parse(f);

            //Chuan
            double test = -(Microsoft.VisualBasic.Financial.Pmt((c / 1200), b, a - fa));
            double test_1 = Math.Round(test);
            //d_t = test_1.ToString();


            //string a_t = textBox1.Text.ToString();
            //string b_t = textBox2.Text.ToString();
            //double c = double.Parse(textBox3.Text.ToString());
            double d_t, f_t;
            //string f = textBox4.Text.ToString();


            //int a = int.Parse(a_t);
            //int b = int.Parse(b_t) * 12;
            //int fa = int.Parse(f);

            abc = (-(Microsoft.VisualBasic.Financial.Pmt((c / 1200), b, a)));
            abc = abc * b;

            d_t = Math.Round((-(Microsoft.VisualBasic.Financial.Pmt((c / 1200), b, a - fa))));
            f_t = Math.Round(d_t * b);




            loanreport.labmo.Text = d_t.ToString();
            loanreport.labpay.Text = f_t.ToString();


        }





    }
}
