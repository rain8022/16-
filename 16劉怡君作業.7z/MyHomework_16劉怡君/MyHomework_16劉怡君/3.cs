﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyHomework_16劉怡君
{
    public partial class _3 : Form
    {
        public _3()
        {
            InitializeComponent();
        }
    }
}
