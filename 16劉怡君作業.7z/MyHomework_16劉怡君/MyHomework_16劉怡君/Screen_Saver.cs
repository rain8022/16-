﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace MyHomework_16劉怡君
{
    public partial class Screen_Saver : Form
    {
        public Screen_Saver()
        {
            InitializeComponent();
        }

       


        Random R = new Random();

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToString();
            label1.Left -= 5;
            if (label1.Right < 0)
            {
                label1.Left = this.ClientSize.Width;
                label1.Top = R.Next(this.Height - label1.Height);
                this.Close();
            }
        }

        private void Screen_Saver_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            this.Close();
        }
    }
}
